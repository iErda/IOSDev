//
//  DescriptionViewController.swift
//  xyy10.15
//
//  Created by Apple on 2019/10/15.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class DescriptionViewController: UIViewController {

     var  foodForEdit:food?
    @IBOutlet weak var nameText: UITextField!
   
    @IBOutlet weak var descriptionText: UITextField!
   
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.nameText.text = foodForEdit?.name//nameText也是一个类
        self.descriptionText.text = foodForEdit?.fooddescription
        self.navigationItem.title = foodForEdit?.name
        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if(segue.identifier == "savetolist"){
            print("save")
            foodForEdit = food(name:self.nameText.text!,fooddescription: self.descriptionText.text!)
        }
        
    }
    

}
