//
//  Enter_CharacterCell.swift
//  ChatModel
//
//  Created by Erda on 2019/10/7.
//  Copyright © 2019 Erda. All rights reserved.
//

import UIKit

class Enter_CharacterCell: UITableViewCell {

    @IBOutlet weak var Icon: UIImageView!
    @IBOutlet weak var Name: UITextView!
    @IBOutlet weak var Description: UITextView!
    @IBOutlet weak var chosenState: UIImageView!
    
    //@objc(Enter_CharacterCell) class Enter_CharacterCell:UITableViewCell {}
    
    var editFalg:Bool = false
    var lastName:String? = nil
    
    @IBOutlet weak var editState: UIButton!
    
    @IBAction func act_edit(_ sender: Any) {
        if editFalg == false{
            Name.backgroundColor = UIColor.gray
            Description.backgroundColor = UIColor.gray
            Name.isEditable = true
            Description.isEditable = true
            editFalg = true
            lastName = Name.text
        }
        else{
            Name.backgroundColor = UIColor.clear
            Description.backgroundColor = UIColor.clear
            Name.isEditable = false
            Description.isEditable = false
            editFalg = false
            CharDataManager.shared.changeCharWith(last:lastName!, name: Name.text, sign: Description.text)
        }
    }
    
 
 
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.selectionStyle = UITableViewCell.SelectionStyle.none
        
    }
    
    override func select(_ sender: Any?) {
        self.select(sender)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        if selected {
            self.chosenState.image = UIImage(named: "icon_yes")
        }else{
            self.chosenState.image = nil
        }
    }
    
    func getCurrentVC(base:UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController?{
        if let nav = base as?UINavigationController{
            return getCurrentVC(base:nav.visibleViewController)
        }
        if let tab = base as? UITabBarController{
            return getCurrentVC(base:tab.selectedViewController)
        }
        if let presented = base?.presentedViewController{
            return getCurrentVC(base:presented)
        }
        return base
    }
    
    
    @IBAction func simpleAlert(_ sender: Any) {
        let alertContl = UIAlertController(title: "详情", message: Description.text, preferredStyle: .alert)
        let okAct = UIAlertAction(title: "好的", style: .default, handler: nil)
        alertContl.addAction(okAct)
        
        getCurrentVC()?.present(alertContl,animated: true,completion:nil)
    }
    
}
