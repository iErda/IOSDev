//
//  NewCharacterViewController.swift
//  ChatModel
//
//  Created by Erda on 2019/10/28.
//  Copyright © 2019 Erda. All rights reserved.
//

import UIKit

class NewCharacterViewController: UIViewController {

    @IBOutlet weak var Name: UITextField!
    @IBOutlet weak var State: UIImageView!
    @IBOutlet weak var Avater: UIImageView!
    @IBOutlet weak var Sign: UITextField!
    @IBOutlet weak var Tips: UITextView!
    
    @IBAction func act_Confirm(_ sender: Any) {
        let name:String = Name.text!
        if name == ""{
            print("wrong")
            State.image = UIImage(named: "icon_no")
             Tips.text = "请填写姓名"
            return
        }
        let res:Character? = CharDataManager.shared.checkWiht(name: name)
        if res == nil{//没找到
            CharDataManager.shared.saveCharWith(name: name,sign:Sign.text ?? "")
            Name.text = ""
            Sign.text = ""
            State.image = UIImage(named: "icon_yes")
            Tips.text = ""
        }
        else {//找到了
            Name.text = ""
            //Sign.text = ""
            State.image = UIImage(named: "icon_no")
            Tips.text = "重名项"
        }
    }
    
    @objc func act_NewAvater(){
        //Todo：手机相册/拍照
        print("hello")
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        Avater.image = UIImage(named: "default_new_image")
        
        let newAvater = UITapGestureRecognizer(target: self, action: #selector(act_NewAvater))//自定义手势
        Avater.addGestureRecognizer(newAvater)//关联对象View
        //Avater.isUserInteractionEnabled = true//允许响应
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
