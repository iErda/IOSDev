//
//  ViewController.swift
//  ChatModel
//
//  Created by Erda on 2019/9/30.
//  Copyright © 2019 Erda. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var Navi: UISegmentedControl!
    
    var ChosenDic:[IndexPath:Int] = [:]
    var ChosenGrp:IndexPath? = []
    
     @IBAction func NaviAction(_ sender: Any) {
        return
     if Navi.selectedSegmentIndex == 0{
        if currentSeg == 0 {
            return
        }
        characterView.reloadData()
        charSelected = [Bool](repeatElement(false, count: characterData.count))
        currentSeg = 0
        chosenCnt = 0
        self.characterView.allowsMultipleSelection = true
        self.Chosen.text = "0 persons chosen"
        
     }
     else{

        if currentSeg == 1{
            return
        }
        characterView.reloadData()
        currentSeg = 1
        chosenCnt = 0
        self.characterView.allowsMultipleSelection = false
        self.Chosen.text = "No group chosen"
        }
     }
    
    @IBOutlet weak var keyWord: UITextField!
    @IBAction func Search(_ sender: Any) {
        let kw:String? = keyWord.text
        keyWord.text = ""
        if kw != nil {
            let res:Character? = CharDataManager.shared.checkWiht(name: kw!)
            if res != nil {
                //二分查找
                let res = binarySearch(kw: kw!)
                if res != -1 {
                        self.characterView.selectRow(at: IndexPath(row: res, section: 0), animated: true, scrollPosition: UITableView.ScrollPosition.top)
                    if self.charSelected[res] == false {
                        self.tableView(characterView, didSelectRowAt: IndexPath(row:res,section:0))
                        self.charSelected[res] = true
                    }
                    
                }
            }
        }
    }
    
    private func binarySearch(kw:String) ->Int{
        let end = characterData.count - 1
        //print ("end: \(end)")
        var p:Int = end
        var q:Int = 0
        var i:Int = end/2
        var tname:String
        while(true){
            print(i)
            tname = characterData[i].name!
            if tname == kw{
                print("over")
                return i
            }
            if i == end {
                break
            }
            
            if tname.compare(kw as! String).rawValue == 1{
                print("<")
                p = i
                i = (p+q)/2
                continue
            }
            else{
                print(">")
                q = i
                i = (p+q)/2
                continue
            }
        }
        return -1
    }
    
    
    @IBOutlet weak var New: UIButton!
    @IBOutlet weak var Enter: UIButton!
    @IBOutlet weak var characterView: UITableView!

    @IBOutlet weak var Chosen: UILabel!
    
    var chosenCnt:Int = 0
    
    var currentSeg:Int = 0
    
    var characterData:[Character] = [Character]()
    
    var charSelected = [Bool](repeatElement(false, count: 50))
    private func cleanUpSelected(){
    charSelected = [Bool](repeatElement(false, count: charSelected.count))
    }
    
    var idSelected = [Int]()
    /*
    var characterData = [
        ["Name":"1 Sharon","Description":"1 Main role"],
        ["Name":"2 Waron","Description":"2 NAN"],
        ["Name":"3 Sharon","Description":"3 Main role"],
        ["Name":"4 Waron","Description":"4 NAN"],
        ["Name":"5 Sharon","Description":"5 Main role"],
        ["Name":"6 Waron","Description":"6 NAN"],
        ["Name":"7 Sharon","Description":"7 Main role"],
        ["Name":"8 Waron","Description":"8 NAN"],
        ["Name":"9 Sharon","Description":"9 Main role"],
        ["Name":"10 Waron","Description":"10 NAN"],
        ["Name":"11 Sharon","Description":"11 Main role"],
        ["Name":"12 Waron","Description":"12 NAN"]    ]
     */
    var groupData = [
        ["Name":"1 group","Description":"1 2 persons"],
        ["Name":"2 group","Description":"2 2 persons"],
        ["Name":"3 group","Description":"3 2 persons"],
        ["Name":"4 group","Description":"4 2 persons"],
        ["Name":"5 group","Description":"5 2 persons"],
        ["Name":"6 group","Description":"6 2 persons"]
    ]

    
    override func viewDidAppear(_ animated: Bool) {
        if Navi.selectedSegmentIndex == 0{
            characterData = CharDataManager.shared.getAllChar()        }
        self.characterView.reloadData()
        if characterData.count > charSelected.count{
            charSelected = [Bool](repeatElement(false, count:characterData.count+charSelected.count))
        }
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        characterData = CharDataManager.shared.getAllChar()

        // Do any additional setup after loading the view, typically from a nib.
        
        /*
         self.characterView = UITableView(frame: view.bounds, style:.grouped)
         */
        
        self.characterView!.dataSource = self
        self.characterView!.delegate = self
        self.characterView!.backgroundColor = UIColor.white
        self.characterView!.register(UINib(nibName: "Enter_CharacterCell", bundle: nil),forCellReuseIdentifier:"enter_characterCell")
        self.characterView!.allowsMultipleSelection = true
        
        
        self.Navi.selectedSegmentIndex = 0
        
        self.Chosen.text = "0 persons chosen"
        
        alertTips(Tit:"须知",Mes:tips[0])
        
    }
    
    let tips:[String] = ["1. 暂时不开放Group；Enter未完成\n 2. cell中记录了目前实现的功能；点击蓝鸟可以查看cell的内容详情\n 3. 调试时发现，模拟器无法输入中文，正在排查，未找到原因",
                         "1. 点击蓝鸟可以查看内容详情\n2. 点击右上角➕可以增加cell项\n3. 未完成头像的添加，但是已在另一个作业上实现\n4. 点击“E”可以更改当前cell项，可改的部分变灰色\n5. 一键清除“Clean Up”，点击后清楚选中的项\n6. 删除，左滑删除\n7.查，搜索，在输入框内输入名字，可以跳转到存在项，若无结果则输入框被清空\n8.排序，增加/删除后自动列表排序\n9. 选中，选中时项的右边标记变绿，列表下方记录了有多少个被选中，若此时删除其中一个或其他，也能得到合理的选中结果\n"
    ]
    
    func alertTips(Tit:String,Mes:String){
        let alert = UIAlertController(title: Tit, message: Mes, preferredStyle:.alert)
        let act = UIAlertAction(title: "知道了", style: .default, handler: nil)
        
        alert.addAction(act)
        present(alert,animated: true)
    }
    @IBAction func alertDir(_ sender: Any) {
        alertTips(Tit:"完整版指引",Mes: tips[1])
    }
    
    
    @IBAction func alertBtn(_ sender: Any) {
        alertTips(Tit:"须知",Mes: tips[0])
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if Navi.selectedSegmentIndex == 0 {
            return self.characterData.count
        }
        return self.groupData.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 95.5
    }
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            if Navi.selectedSegmentIndex == 0 {
                if ChosenDic[indexPath] != nil {//后台数据：已选择
                ChosenDic.removeValue(forKey: indexPath)
                }
                
                let item = characterData[indexPath.row]//后台数据：存在有
                CharDataManager.shared.deleteWith(name:item.name!)//远程数据：存在有
                characterData.remove(at: indexPath.row)//后台数据：存在有
                
                //前台列表中删除
                self.characterView.deleteRows(at: [indexPath], with: .fade)
                
                /*
                characterData.remove(at: indexPath.row)
                 if charSelected[indexPath.row] == true {
                 self.tableView(self.characterView, didDeselectRowAt: indexPath)
                 }
                */
                
                var tempDic:[IndexPath:Int] = [:]
                
                //随着删除某个item，而更改其他所选中item的序列，注意在for循环内应该谨慎，不要改变for对象的规模大小，而采用了
                //temp暂存
                for (dicPath,_) in ChosenDic{
                    print("\(dicPath.row) : \(indexPath.row)")
                    if dicPath.row > indexPath.row {
                        tempDic[IndexPath(row: dicPath.row - 1, section: 0)] = dicPath.row - 1
                          /*
                        print("-: \(dicPath.row-1)")
                        tableView.selectRow(at: IndexPath(row:dicPath.row - 1, section: 0), animated: true, scrollPosition: .none)
 */
                        
                    }else{
                        tempDic[dicPath] = dicPath.row
                    }
                }
                
                ChosenDic = tempDic
 
            }else{
                if ChosenGrp == indexPath{
                    ChosenGrp = nil
                }
                self.characterView.deleteRows(at: [indexPath], with: .fade)
            }
        }
    }
    
    
    //由于editing编辑状态会把cell的selected全部忘记，因此需要在didEndEditingRowAt函数中，通过第三方selected的存储，
    //恢复列表中的选中状态
    func tableView(_ tableView: UITableView, didEndEditingRowAt indexPath: IndexPath?) {
        if indexPath == nil {return}
        if Navi.selectedSegmentIndex == 0 {
            //此时面对的是一个item下标为新的ChosenDic，因此直接更新就可以了
        for (dicPath,_) in ChosenDic{
            print("\(dicPath.row) : \(indexPath!.row)")
            tableView.selectRow(at: dicPath, animated: true, scrollPosition: .none)
        }
        self.Chosen.text = "\(ChosenDic.count) persons chosen"
        }
        else{
            var row:Int = ChosenGrp!.row
            if ChosenGrp == nil{
                self.Chosen.text = "no Group is chosen"
                return
            }
            else{
                if ChosenGrp!.row > indexPath!.row {
                    row -= 1
                }
                
                let itemData = groupData[row]
                self.Chosen.text = "\(itemData["Name"]!) is chosen"
                
            }
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if Navi.selectedSegmentIndex == 0 {
            let cell:Enter_CharacterCell = self.characterView.dequeueReusableCell(withIdentifier: "enter_characterCell", for: indexPath) as! Enter_CharacterCell
            
            let itemData = self.characterData[indexPath.row]
            cell.Name?.text = itemData.name//itemData["Name"]
            cell.Description?.text = (itemData.sign == nil ?"hello":itemData.sign)//itemData["Description"]
            cell.Description?.isEditable = false
            cell.Icon?.image = UIImage(named:"icon 1")
            print("show:\(indexPath.row)")
            
            return cell
            
        }
        else{
            let cell:Enter_CharacterCell = self.characterView.dequeueReusableCell(withIdentifier: "enter_characterCell", for: indexPath) as! Enter_CharacterCell
            
            let itemData = self.groupData[indexPath.row]
            cell.Name?.text = itemData["Name"]
            cell.Description?.text = itemData["Description"]
            cell.Description?.isEditable = false
            cell.Icon?.image = UIImage(named:"icon 2")
            print("show:\(indexPath.row)")
            
            return cell
            
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if Navi.selectedSegmentIndex == 0{
            if ChosenDic[indexPath] == nil{
                ChosenDic[indexPath] = ChosenDic.count
                self.Chosen.text = "\(ChosenDic.count) persons chosen"

            }
        }else{
            let itemData = groupData[indexPath.row]
            self.Chosen.text = "\(itemData["Name"]!) is chosen"
        }
        /*
        if Navi.selectedSegmentIndex == 0 {
            if charSelected[indexPath.row] == true{
                return
            }
            charSelected[indexPath.row] = true
            chosenCnt += 1
            self.Chosen.text = "\(chosenCnt) persons chosen"
        }else{
            let itemData = groupData[indexPath.row]
            self.Chosen.text = "\(itemData["Name"]!) is chosen"
        }
 */
    }
    
    @IBAction func act_cleanUp(_ sender: Any) {
        if Navi.selectedSegmentIndex == 0{
            if ChosenDic.isEmpty {return}
            for (indexPath,_) in ChosenDic {

                characterView.deselectRow(at: indexPath, animated: true)
            }
            ChosenDic = [:]
            self.Chosen.text = "\(ChosenDic.count) persons chosen"

        }else{
            if ChosenGrp == nil{return}
            characterView.deselectRow(at: ChosenGrp!, animated: true)
            self.Chosen.text = "no Group is chosen"

        }
    }
    
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        if Navi.selectedSegmentIndex == 0{
            if ChosenDic[indexPath] != nil {
                ChosenDic.removeValue(forKey: indexPath)
                self.Chosen.text = "\(ChosenDic.count) persons chosen"
                
            }
        }else{
            self.Chosen.text = "no Group is chosen"
        }
    }

}
