//
//  Enter_GroupCell.swift
//  ChatModel
//
//  Created by Erda on 2019/10/7.
//  Copyright © 2019 Erda. All rights reserved.
//

import UIKit

class Enter_GroupCell: UITableViewCell {

    @IBOutlet weak var Group: UILabel!
    @IBOutlet weak var Description: UITextView!
    @IBOutlet weak var Icon: UIImageView!
    @IBOutlet weak var chosenState: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.Description.isEditable = false
    }
}
