//
//  CharDataManager.swift
//  ChatModel
//
//  Created by Erda on 2019/10/28.
//  Copyright © 2019 Erda. All rights reserved.
//

import UIKit
import CoreData

class CharDataManager:NSObject{
    //singleton
    static let shared = CharDataManager()
    
    lazy var context:NSManagedObjectContext = {
        let context = ((UIApplication.shared.delegate) as! AppDelegate).context
        return context
    }()
    
    private func saveContext(){
        do{
            try context.save()
        }catch{
            let nserror = error as NSError
            fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
        }
    }
    
    func saveCharWith(name:String,sign:String){
        let char = NSEntityDescription.insertNewObject(forEntityName: "Character", into: context) as! Character
        char.name = name
        char.sign = sign
        saveContext()
    }
    
    func changeCharWith(last: String,name:String,sign:String){
        let request:NSFetchRequest = Character.fetchRequest()
        let predicate = NSPredicate(format: "name == '" + last + "'")
        request.predicate = predicate
        var char:Character? = nil
        do{
            let res:[Character] = try context.fetch(request)
            if res.count > 0{
                char = res[0] //找到了
            }
        }catch {
            print("no character exisisted")
            return
        }
        char!.name = name
        char!.sign = sign
        saveContext()
    }
    
    func getAllChar()->[Character]{
        let fetchRequest:NSFetchRequest = Character.fetchRequest()
        let sorDes = NSSortDescriptor(key: "name", ascending: true)//对结果排序
        fetchRequest.sortDescriptors = [sorDes]
        do{
            let result = try context.fetch(fetchRequest)
            return result
        }catch{
            fatalError()
        }
    }
    
    func deleteWith(name:String){
        let request:NSFetchRequest = Character.fetchRequest()
        let predicate = NSPredicate(format: "name == '" + name + "'")
        request.predicate = predicate
        var char:Character? = nil
        do{
            let res:[Character] = try context.fetch(request)
            if res.count > 0{
               char = res[0] //找到了
                context.delete(char!)
                saveContext()
            }
        }catch {
            return
        }
    }
    
    func checkWiht(name:String)->Character?{
        let request:NSFetchRequest = Character.fetchRequest()
        let predicate = NSPredicate(format: "name == '" + name + "'")
        request.predicate = predicate
        do{
            let res:[Character] = try context.fetch(request)
            if res.count > 0{
                return res[0] //找到了
            }
          }catch {
        }
        return nil//没找到
    }
    
}
