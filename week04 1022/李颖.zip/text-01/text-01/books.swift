//
//  books.swift
//  text-01
//
//  Created by Apple on 2019/10/15.
//  Copyright © 2019 sun. All rights reserved.
//

import Foundation
import UIKit

class book:NSObject,NSCoding{
    var name: String
    var desc:String
    var bookimage:UIImage?
    var author:String?
    
    init(name:String?,desc:String?,image:UIImage?,author:String?) {
        self.name = name ?? "《霸道总裁爱上我》"
        self.desc = desc ?? "当代恶臭小说"
        self.bookimage = image
        self.author = author
    }
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("books")

    func encode(with aCoder: NSCoder) {
        aCoder.encode(name, forKey: "nameKey")
        aCoder.encode(desc, forKey: "descKey")
        aCoder.encode(author, forKey: "authorKey")
        aCoder.encode(bookimage, forKey: "imageKey")
    }
    
    required init?(coder aDecoder: NSCoder) {
        name = aDecoder.decodeObject(forKey: "nameKey") as? String ?? "default value"
        desc = (aDecoder.decodeObject(forKey: "descKey") as? String)!
        author = (aDecoder.decodeObject(forKey: "authorKey") as? String)!
        bookimage = (aDecoder.decodeObject(forKey: "imageKey") as? UIImage)
    }
}

