//
//  TableViewCell.swift
//  text-01
//
//  Created by Apple on 2019/10/29.
//  Copyright © 2019 sun. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    //@IBOutlet weak var bookdesc: UILabel!
    //@IBOutlet var author: UILabel!
    
    @IBOutlet weak var bookimage: UIImageView!
    @IBOutlet weak var desc: UILabel!
    @IBOutlet weak var author: UILabel!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    
        // Configure the view for the selected state
    }

}
