//
//  descViewController.swift
//  text-01
//
//  Created by Apple on 2019/10/15.
//  Copyright © 2019 sun. All rights reserved.
//

import UIKit

class descViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate{

    
    @IBOutlet weak var bookimage: UIImageView!
    @IBOutlet weak var bookname: UITextField!
    @IBOutlet weak var bookdesc: UITextField!
    var curbook:book?
    
    @IBOutlet weak var author: UITextField!
    
    @IBAction func addimage(_ sender: Any) {
        
        let imagepicker = UIImagePickerController()
        imagepicker.sourceType = .photoLibrary
        imagepicker.delegate = self
        present(imagepicker,animated: true,completion: nil)
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.bookname.text = curbook?.name
        self.bookdesc.text = curbook?.desc
        self.author.text = curbook?.author
        self.navigationItem.title = curbook?.name
        bookimage.image = curbook?.bookimage
        // Do any additional setup after loading the view.
    }
    
    func savebook()->(name:String,desc:String,author:String,image:UIImage)
    {
       //books.append(book(name:self.bookname.text,desc:self.bookname.text))
        //let success = NSKeyedArchiver.archiveRootObject(<#T##rootObject: Any##Any#>, toFile: <#T##String#>)
        //if !success{print("Filed…")}
        
        return (self.bookname.text!,self.bookdesc.text!,self.author.text!,self.bookimage.image!)
    }
    
  
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if(segue.identifier == "saveToList")
        {
            print("save")
            let bk=savebook()
            curbook = book(name:bk.name,desc:bk.desc,image:bk.image,author: bk.author)
        }
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    
    
    func imagePickerController(_ pick:UIImagePickerController,didFinishPickingMediaWithInfo info:[UIImagePickerController.InfoKey:Any])
    {
        let selectedImage=info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        self.bookimage.image=selectedImage
        
        dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
