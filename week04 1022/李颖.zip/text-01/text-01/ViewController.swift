//
//  ViewController.swift
//  text-01
//
//  Created by Apple on 2019/10/15.
//  Copyright © 2019 sun. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

  
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

