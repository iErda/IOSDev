//
//  ViewController.swift
//  test
//
//  Created by Apple on 2019/9/10.
//  Copyright © 2019 sun. All rights reserved.
//

import UIKit
//用于交互的基本的包

class ViewController: UIViewController {

    override func viewDidLoad() {//必须重载该函数，view完全加载后，
        super.viewDidLoad()
        print("hello world!")
        //setupGame()
        // Do any additional setup after loading the view.
    }
    @IBOutlet var Label_1: UILabel!
    @IBOutlet var Label_2: UILabel!
    @IBOutlet var Label_3: UILabel!
    var count=0
    var seconds = 30
    var timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: Selector(("subtractTime")), userInfo: nil, repeats: true)
    
    @IBAction func buttonPressed()  {
        NSLog("Button Pressed")
        count+=1
        Label_3.text = "Sorce : \(count)"
        
    }
    func setupGame()  {
        seconds = 30
        count = 0
        
        Label_2.text = "Time : \(seconds)"
        Label_3.text = "Score : \(count)"
        
        
        timer.fireDate = Date.init(timeIntervalSinceNow: 3.0)
     
    }
    
    func subtractTime() {
        seconds=seconds-1
        Label_2.text = "Time : \(seconds)"
        
        if(seconds == 0)  {
            timer.invalidate()
        }
    }
    

}

