import Cocoa

var numbers = [20,19,7,12]
numbers.map({
    (number: Int) -> Int in
    let result = 3 * number
    return result
})

