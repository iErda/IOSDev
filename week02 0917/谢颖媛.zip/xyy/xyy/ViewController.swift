//
//  ViewController.swift
//  xyy
//
//  Created by Apple on 2019/9/3.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit//用于交互的包

class ViewController: UIViewController {//有意义的命名，基本都从UIViewController继承

    override func viewDidLoad() {//一般都需要加载
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print("viewDidLoad")
    }


}

